public class Do_while {
    public static void main(String[]args){
        int n=10 ,i=0;
        do{
            System.out.println(n);
            --n;
        }
        while(n>i);
    }
    
}