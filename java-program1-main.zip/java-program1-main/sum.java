class Sum {
    public static void main(String[] args) {
   int a=5,b=6,c;
   c=a+b;
    System.out.println(c);
    }
}