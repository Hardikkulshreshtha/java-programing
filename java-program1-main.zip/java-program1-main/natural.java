class natural {
    public static void main(String args[])
    {
        int n=10;
        System.out.println("Natural nos from 1 to n are");
        for(int i=1;i<=n;i++)
        {
            System.out.print(i+" ");
        }
    }
}