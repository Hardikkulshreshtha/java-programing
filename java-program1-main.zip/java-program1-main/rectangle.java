class rectangle {
    public static void main(String[] args) {
        int len=2,wid=4,c;
        c=len*wid;
    {
    System.out.println(c);
    
    }
}
}