class circle {
    public static void main(String[] args) {
        double radius=5,pi=3.14;
        double c;
        c=pi*radius*radius;
    
    System.out.println(c);
    
    }
}