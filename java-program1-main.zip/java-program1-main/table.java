class table {
    public static void main(String[] args)
    {
       
        int N = 7;
 
       
        for (int i = 1; i <= 10; i++) {
            System.out.println(N + " * " + i + " = "
                               + N * i);
        }
    }
}