class interest {
    public static void main(String[] args) {
       int p=1000,r=2,t=3,c;
       c=p*r*t/100;
    
    System.out.println(c);
    
    }
}