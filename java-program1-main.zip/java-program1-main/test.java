class Test {
    public static void main(String[] args) {
    System.out.println("Jai Gla ");
    System.out.println("Harsh Kumar");
    System.out.println("2215000735");
    }
}